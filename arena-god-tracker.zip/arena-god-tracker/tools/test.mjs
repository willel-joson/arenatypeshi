/* Drives the real page in jsdom and asserts on observable behaviour. */
import { JSDOM, VirtualConsole } from 'jsdom';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const html = readFileSync(join(ROOT, 'index.html'), 'utf8');

let pass = 0, fail = 0;
const consoleErrors = [];

function ok(label, cond, extra = '') {
  if (cond) { pass++; console.log(`  ok   ${label}`); }
  else { fail++; console.log(`  FAIL ${label}${extra ? '  → ' + extra : ''}`); }
}
function eq(label, actual, expected) {
  ok(label, Object.is(actual, expected), `got ${JSON.stringify(actual)}, want ${JSON.stringify(expected)}`);
}

/* A localStorage that survives "reloads", like a real browser profile. */
function makeStorage(seed = {}) {
  const map = new Map(Object.entries(seed));
  return {
    getItem: k => (map.has(k) ? map.get(k) : null),
    setItem: (k, v) => map.set(k, String(v)),
    removeItem: k => map.delete(k),
    clear: () => map.clear(),
    key: i => [...map.keys()][i] ?? null,
    get length() { return map.size; },
    _dump: () => Object.fromEntries(map)
  };
}

async function boot(storage) {
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => consoleErrors.push('jsdomError: ' + e.message));
  vc.on('error', (...a) => consoleErrors.push('console.error: ' + a.join(' ')));

  const dom = new JSDOM(html, {
    url: 'https://example.github.io/arena-god/',
    runScripts: 'dangerously',
    resources: undefined,        // don't fetch icons/fonts
    pretendToBeVisual: true,
    virtualConsole: vc,
    beforeParse(win) {
      Object.defineProperty(win, 'localStorage', { value: storage, configurable: true });
      win.confirm = () => true;
      win.URL.createObjectURL = () => 'blob:stub';
      win.URL.revokeObjectURL = () => {};
    }
  });

  // Load the two local scripts by hand (resources are disabled).
  const win = dom.window;
  win.eval(readFileSync(join(ROOT, 'champions.js'), 'utf8'));
  win.eval(readFileSync(join(ROOT, 'app.js'), 'utf8'));
  win.document.dispatchEvent(new win.Event('DOMContentLoaded'));
  return dom;
}

const $ = (d, s) => d.window.document.querySelector(s);
const $$ = (d, s) => [...d.window.document.querySelectorAll(s)];
const visible = d => $$(d, '.tile').filter(t => !t.hidden);
const click = (d, node) => node.dispatchEvent(new d.window.MouseEvent('click', { bubbles: true }));

function type(d, value) {
  const input = $(d, '#search');
  input.value = value;
  input.dispatchEvent(new d.window.Event('input', { bubbles: true }));
}

const storage = makeStorage();

console.log('\nBuild + initial render');
let dom = await boot(storage);
eq('renders every champion tile', $$(dom, '.tile').length, 173);
eq('rail has 60 notches', $$(dom, '.notch').length, 60);
eq('starts at zero', $(dom, '#tally-count').textContent, '0');
eq('remaining copy', $(dom, '#tally-remaining').textContent, '60 champions to go');
ok('roster line mentions full roster', $(dom, '#tally-roster').textContent.includes('of 173'));
eq('no notch lit', $$(dom, '.notch.lit').length, 0);
ok('crown message hidden', $(dom, '#crowned').hidden);
eq('progressbar value', $(dom, '#rail').getAttribute('aria-valuenow'), '0');

console.log('\nToggling');
const jinx = $(dom, '.tile[data-id="Jinx"]');
click(dom, jinx);
ok('tile marked won', jinx.classList.contains('is-won'));
eq('aria-pressed set', jinx.getAttribute('aria-pressed'), 'true');
eq('count is 1', $(dom, '#tally-count').textContent, '1');
eq('one notch lit', $$(dom, '.notch.lit').length, 1);
eq('remaining is singular-aware', $(dom, '#tally-remaining').textContent, '59 champions to go');

click(dom, jinx);
ok('toggles back off', !jinx.classList.contains('is-won'));
eq('count back to 0', $(dom, '#tally-count').textContent, '0');
click(dom, jinx); // leave it on

console.log('\nSearch');
type(dom, 'ka');
ok('partial match filters down', visible(dom).length > 0 && visible(dom).length < 173);
ok('matches are case-insensitive substrings',
  visible(dom).every(t => t.querySelector('.tile__name').textContent.toLowerCase().replace(/[^a-z0-9]/g, '').includes('ka')));
type(dom, 'KAI');
ok('uppercase query works', visible(dom).some(t => t.dataset.id === 'Kaisa'));
type(dom, 'kaisa');
eq("punctuation-free search finds Kai'Sa", visible(dom).length, 1);
type(dom, 'drmundo');
eq('finds Dr. Mundo without the dot/space', visible(dom).length, 1);
type(dom, 'wukong');
eq('finds Wukong by display name (id is MonkeyKing)', visible(dom).length, 1);
type(dom, 'zzzz');
eq('no matches', visible(dom).length, 0);
ok('empty state shown', !$(dom, '#empty').hidden);
type(dom, '');
eq('clearing restores all', visible(dom).length, 173);
ok('empty state hidden again', $(dom, '#empty').hidden);
eq('showing line blank when unfiltered', $(dom, '#showing').textContent, '');

console.log('\nRole filters');
const chip = r => $(dom, `.chip[data-role="${r}"]`);
click(dom, chip('Tank'));
const tanks = visible(dom).length;
ok('tank filter narrows the grid', tanks > 0 && tanks < 173);
ok('all visible are tanks', visible(dom).every(t => t.title.includes('Tank')));
click(dom, chip('Mage'));
ok('roles are additive (OR)', visible(dom).length > tanks);
ok('union only contains the two classes',
  visible(dom).every(t => t.title.includes('Tank') || t.title.includes('Mage')));
click(dom, chip('Mage'));
eq('deselecting a chip restores', visible(dom).length, tanks);

console.log('\nSearch + role compose');
type(dom, 'sh');
ok('search narrows within the role filter',
  visible(dom).length <= tanks && visible(dom).every(t => t.title.includes('Tank')));
ok('showing line reports the subset', $(dom, '#showing').textContent.startsWith('Showing '));
click(dom, $(dom, '.chip[data-role=""]'));
eq('"Every class" clears roles', $$(dom, '.chip.is-on').length, 1);
type(dom, '');

console.log('\nWon / Remaining toggle');
click(dom, $(dom, '.seg__btn[data-status="won"]'));
eq('only won champions listed', visible(dom).length, 1);
eq('and it is the one we marked', visible(dom)[0].dataset.id, 'Jinx');
click(dom, $(dom, '.seg__btn[data-status="todo"]'));
eq('remaining excludes the won one', visible(dom).length, 172);
click(dom, chip('Marksman'));
ok('status composes with role',
  visible(dom).every(t => t.title.includes('Marksman')) && !visible(dom).some(t => t.dataset.id === 'Jinx'));
click(dom, $(dom, '.chip[data-role=""]'));
click(dom, $(dom, '.seg__btn[data-status="all"]'));
eq('back to everything', visible(dom).length, 173);

console.log('\nPersistence across a reload');
ok('wrote to localStorage', storage.getItem('arenaGod.progress.v1') !== null);
dom.window.close();
dom = await boot(storage);
eq('count restored', $(dom, '#tally-count').textContent, '1');
ok('tile restored as won', $(dom, '.tile[data-id="Jinx"]').classList.contains('is-won'));
eq('notch restored', $$(dom, '.notch.lit').length, 1);

console.log('\nThe 60 cap');
const ids = dom.window.CHAMPIONS.map(c => c.id).slice(0, 70);
ids.forEach(id => {
  const t = $(dom, `.tile[data-id="${id}"]`);
  if (!t.classList.contains('is-won')) click(dom, t);
});
const marked = $$(dom, '.tile.is-won').length;
eq('marked more than sixty', marked, 70); // Jinx is already inside the first 70
eq('counter caps at 60', $(dom, '#tally-count').textContent, '60');
eq('all 60 notches lit, no more', $$(dom, '.notch.lit').length, 60);
eq('progressbar caps too', $(dom, '#rail').getAttribute('aria-valuenow'), '60');
ok('completion message shown', !$(dom, '#crowned').hidden);
ok('overflow reported honestly', $(dom, '#tally-roster').textContent.includes('10 past the goal'));
eq('remaining reads complete', $(dom, '#tally-remaining').textContent, 'Complete');

console.log('\nExport');
let downloadName = null, blobText = null;
dom.window.HTMLAnchorElement.prototype.click = function () { downloadName = this.download; };
dom.window.Blob = class { constructor(parts) { blobText = parts.join(''); } };
click(dom, $(dom, '#export'));
eq('filename', downloadName, 'arena-god-progress.json');
const exported = JSON.parse(blobText);
eq('exports every marked champion', exported.champions.length, 70);
eq('stamped with the patch', exported.patch, dom.window.DDRAGON_VERSION);
ok('export is sorted', exported.champions.join() === [...exported.champions].sort().join());

console.log('\nReset');
click(dom, $(dom, '#reset'));
eq('all cleared', $(dom, '#tally-count').textContent, '0');
eq('no tiles marked', $$(dom, '.tile.is-won').length, 0);
ok('crown message hidden again', $(dom, '#crowned').hidden);

console.log('\nImport');
function importText(text, name = 'progress.json') {
  const win = dom.window;
  const input = $(dom, '#import');
  const file = { name, type: 'application/json' };
  Object.defineProperty(input, 'files', { value: [file], configurable: true });
  const RealFR = win.FileReader;
  win.FileReader = class {
    readAsText() { this.result = text; if (this.onload) this.onload(); }
  };
  input.dispatchEvent(new win.Event('change', { bubbles: true }));
  win.FileReader = RealFR;
}

importText(JSON.stringify({ app: 'arena-god-tracker', champions: ['Jinx', 'Ashe', 'Sett'] }));
eq('imported count', $(dom, '#tally-count').textContent, '3');
ok('imported tile marked', $(dom, '.tile[data-id="Sett"]').classList.contains('is-won'));
ok('confirmation message', $(dom, '#save-msg').textContent.includes('Imported 3 champions'));

importText(JSON.stringify(['Ahri', 'Zed']));
eq('bare array also accepted', $(dom, '#tally-count').textContent, '2');

importText(JSON.stringify({ champions: ['Ahri', 'NotAChampion', 'Teemo'] }));
eq('unknown ids dropped', $(dom, '#tally-count').textContent, '2');
ok('and reported', $(dom, '#save-msg').textContent.includes('Skipped 1'));

importText('{ not json');
ok('bad JSON is handled', $(dom, '#save-msg').textContent.includes("isn't valid JSON"));
ok('error styled as error', $(dom, '#save-msg').classList.contains('is-bad'));
eq('state untouched by bad import', $(dom, '#tally-count').textContent, '2');

importText(JSON.stringify({ hello: 'world' }));
ok('wrong shape is handled', $(dom, '#save-msg').textContent.includes('No champion list'));

console.log('\nCorrupt saved state');
const badStore = makeStorage({ 'arenaGod.progress.v1': '{{{ broken' });
const dom2 = await boot(badStore);
eq('recovers from a corrupt entry', $(dom2, '#tally-count').textContent, '0');
eq('grid still renders', $$(dom2, '.tile').length, 173);
dom2.window.close();

console.log('\nStorage disabled (private mode)');
const throwing = {
  getItem() { throw new Error('denied'); },
  setItem() { throw new Error('denied'); },
  removeItem() { throw new Error('denied'); }
};
const dom3 = await boot(throwing);
eq('still renders without storage', $$(dom3, '.tile').length, 173);
click(dom3, $(dom3, '.tile[data-id="Ahri"]'));
eq('toggling still works in memory', $(dom3, '#tally-count').textContent, '1');
ok('user is told saving failed', $(dom3, '#save-msg').textContent.includes('blocking storage'));
dom3.window.close();

console.log('\nConsole');
eq('no console errors or uncaught exceptions', consoleErrors.length, 0,
   consoleErrors.join(' | '));

dom.window.close();
console.log(`\n${pass} passed, ${fail} failed\n`);
process.exit(fail ? 1 : 0);
