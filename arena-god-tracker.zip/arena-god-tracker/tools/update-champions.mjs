#!/usr/bin/env node
/**
 * Regenerate champions.js from Riot's Data Dragon.
 *
 *   node tools/update-champions.mjs           # refresh names, ids and class tags
 *   node tools/update-champions.mjs --icons   # also download every square icon
 *
 * Run this after a patch, commit the result, and the deployed page keeps
 * working even if Data Dragon is unreachable. Requires Node 18+.
 */

import { writeFile, mkdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const WITH_ICONS = process.argv.includes('--icons');
const VALID = ['Assassin', 'Fighter', 'Mage', 'Marksman', 'Support', 'Tank'];

async function getJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${res.status} ${res.statusText} for ${url}`);
  return res.json();
}

const versions = await getJSON('https://ddragon.leagueoflegends.com/api/versions.json');
const version = versions[0];
console.log(`Data Dragon version: ${version}`);

const { data } = await getJSON(
  `https://ddragon.leagueoflegends.com/cdn/${version}/data/en_US/champion.json`
);

const champions = Object.values(data)
  .map(({ id, name, tags }) => ({ id, name, tags }))
  .sort((a, b) => a.id.toLowerCase().localeCompare(b.id.toLowerCase()));

console.log(`Champions: ${champions.length}`);

const odd = champions.filter(c => !c.tags?.length || c.tags.some(t => !VALID.includes(t)));
if (odd.length) {
  console.warn('Unexpected class tags (filters may need a new chip):');
  for (const c of odd) console.warn(`  ${c.id}: ${JSON.stringify(c.tags)}`);
}

const body = champions
  .map(c => `  { id: ${JSON.stringify(c.id)}, name: ${JSON.stringify(c.name)}, ` +
            `tags: [${c.tags.map(t => `'${t}'`).join(', ')}] }`)
  .join(',\n');

const file = `/*
 * Champion roster — generated from Riot Data Dragon.
 * Patch: ${version}   Champions: ${champions.length}
 *
 * Regenerate after each patch with:  node tools/update-champions.mjs
 *
 * \`id\` is the Data Dragon key, used to build the square icon URL:
 *   https://ddragon.leagueoflegends.com/cdn/<version>/img/champion/<id>.png
 */
window.DDRAGON_VERSION = '${version}';

window.CHAMPIONS = [
${body}
];
`;

await writeFile(join(ROOT, 'champions.js'), file, 'utf8');
console.log('Wrote champions.js');

if (WITH_ICONS) {
  const dir = join(ROOT, 'icons');
  if (!existsSync(dir)) await mkdir(dir, { recursive: true });

  let done = 0;
  for (const c of champions) {
    const res = await fetch(
      `https://ddragon.leagueoflegends.com/cdn/${version}/img/champion/${c.id}.png`
    );
    if (!res.ok) {
      console.warn(`  missed ${c.id} (${res.status})`);
      continue;
    }
    await writeFile(join(dir, `${c.id}.png`), Buffer.from(await res.arrayBuffer()));
    done++;
  }

  console.log(`Downloaded ${done} icons to icons/`);
  console.log("Now set ICON_BASE in app.js to './icons/' to serve them locally.");
}
